export const lang = (payload) => ({
  type: "CURRENT_TYPE",
  payload,
});
